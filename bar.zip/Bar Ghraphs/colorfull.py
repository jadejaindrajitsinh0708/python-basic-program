import matplotlib.pyplot as plt
import numpy as np

color = np.array(["red","blue","green","yellow","orange"])
values = np.array([10,20,30,20,10])

plt.bar(color, values, color=color)
plt.title("Colorful Bar Graph 🌈")
plt.xlabel("Colors")
plt.ylabel("Values")

plt.show()