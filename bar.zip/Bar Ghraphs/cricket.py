import matplotlib.pyplot as plt 
import numpy as np 

player = np.array(["p1","p2","p3","p4","p5","p6","p7","p8","p9","p10","p11"])
teams_1 = np.array([50,54,52,36,42,45,26,50,22,20,55])
teams_2 = np.array([45,25,25,35,26,35,14,41,21,18,10])


plt.bar(player,teams_1,color="red",label="red") 
plt.bar(player,teams_2,color="yellow",label="yellow")
plt.title("score of two teams")
plt.xlabel("number of players")
plt.ylabel("Score of match")
plt.show()