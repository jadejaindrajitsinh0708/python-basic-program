import matplotlib.pyplot as plt
import numpy as np

namkeen = np.array(["kelawafar","gathiya","khakhara"])
sales = np.array([100, 60, 170])

plt.bar(namkeen,sales,color="orange")
plt.title("Namkeen Sales 📊")
plt.xlabel("Namkeen")
plt.ylabel("Sales in thousands")
plt.show()  

