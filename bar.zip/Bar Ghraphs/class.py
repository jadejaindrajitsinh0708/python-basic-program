import matplotlib.pyplot as plt
import numpy as np

classes = np.array(["B.com", "B.sc", "BBA", "BCA", "B.tech"])
students = np.array([120, 150, 100, 130, 170])

plt.bar(classes, students, color="blue")
plt.title("Number of Students in Different Classes 🎓")
plt.xlabel("Classes")
plt.ylabel("Number of Students")
plt.show()
