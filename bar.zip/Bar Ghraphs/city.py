import matplotlib.pyplot as plt
import numpy as np

city = np.array(["delhi","mumbai","kolkata","chennai","bangalore"])
population = np.array([190,120, 150, 100, 80])
plt.bar(city,population,color="blue")
plt.title("City Population 🌆")
plt.xlabel("City")
plt.ylabel("Population in lakhs ")
plt.show()
