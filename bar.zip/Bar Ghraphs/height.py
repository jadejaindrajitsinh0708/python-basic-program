import matplotlib.pyplot as plt
import numpy as np

student = np.array(["dev","sachin","rohit","virat","dhoni"])
heights = np.array([5.8, 5.9, 6.0, 5.7, 5.6])
plt.bar(student,heights,color="orange")
plt.title("Student Heights 📏")
plt.xlabel("Student")
plt.ylabel("Height in feet")
plt.show()



