import matplotlib.pyplot as plt 
import numpy as np

marks_1 = np.array([80, 90, 70, 85, 95])
marks_2 = np.array([75, 85, 65, 80, 90])
Name = np.array(["Student 1", "Student 2", "Student 3", "Student 4", "Student 5"])

plt.bar(Name, marks_1, color="green", label="boya")
plt.bar(Name, marks_2, color="yellow", label="girls")
plt.title("Marks of Students")
plt.xlabel("Students")
plt.ylabel("Marks")
plt.legend()
plt.show()

