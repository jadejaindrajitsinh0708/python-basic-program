import matplotlib.pyplot as plt 
import numpy as np

salaries = np.array([25000,50000,36000,100000,12000])
department = np.array(["sales","manager","head manager","CA","cleaner"])
color  = np.array(["orange","pink","blue","green","grey"])
plt.bar(department,salaries,color=color)
plt.title("department salaries")
plt.xlabel("Name of department ")
plt.ylabel("Salaries in Rupess 💸")
plt.show()

