import matplotlib.pyplot as plt 
import numpy as np 

subject = np.array(["AI","ML","DS","Python","Java"])
sales = np.array([50, 60, 70, 80, 90])
plt.bar(subject,sales,color="purple")
plt.title("Subject Sales 📊")
plt.xlabel("Subject")
plt.ylabel("Sales in thousands")
plt.show()