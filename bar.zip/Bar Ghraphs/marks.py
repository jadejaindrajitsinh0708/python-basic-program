import matplotlib.pyplot as plt
import numpy as np

name = np.array(["dev","sachin","rohit","virat","dhoni"])
marks = np.array([85, 90, 78, 92, 88])

plt.bar(name,marks,color="green")
plt.title("student marks 📑")
plt.xlabel("name of student")
plt.ylabel("number of marks out of 100")
plt.show()
